import datetime
from flask import Flask, request, render_template
import json
app = Flask(__name__)  # создаем веб-приложение


def load_chat():
    with open("chat.json", 'r') as json_file:
        data = json.load(json_file)
        return data["messages"]


all_messages = load_chat()


def save_chat():
    data = {'messages': all_messages}
    with open("chat.json", 'w') as json_file:
        json.dump(data, json_file)


@app.route("/chat")
def display_chat():
    return render_template("form.html")


@app.route("/")
def index_page():
    return "Welcome to MyMessenger"


@app.route("/get_messages")
def get_messages():
    return {"messages": all_messages}


@app.route("/send_message")
def send_message():
    sender = request.args["name"]
    text = request.args["text"]
    save_chat()
    if 2 < len(sender) < 101 and 0 < len(text) < 3000:
        add_message(sender, text)
        return 'OK'
    else:
        add_message("Security_Bot", "ERROR")
        return "ERROR"


@app.route("/info")
def info_page():
    answer = "Number of messages: " + str(len(all_messages))
    return answer


# Функция добавляения нового сообщения
def add_message(sender, text):
    new_message = {
        "sender": sender,
        "text": text,
        "time": datetime.datetime.now().strftime('%d %b, %H:%M')
    }
    all_messages.append(new_message)


app.run()
